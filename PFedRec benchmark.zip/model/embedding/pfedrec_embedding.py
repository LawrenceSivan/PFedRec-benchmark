from model.embedding.base_embedding import BaseEmbedding

class PFedRecEmbedding(BaseEmbedding):
    def __init__(self, num_items, latent_dim):
        super(PFedRecEmbedding, self).__init__(num_embeddings=num_items, embedding_dim=latent_dim)

