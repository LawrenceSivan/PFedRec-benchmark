import torch.nn as nn
from model.prediction.base_prediction import BasePrediction

class PFedRecPrediction(BasePrediction):
    def __init__(self, input_dim):
        super(PFedRecPrediction, self).__init__()
        self.affine_output = nn.Linear(in_features=input_dim, out_features=1)
        self.logistic = nn.Sigmoid()

    def forward(self, x):
        logits = self.affine_output(x)
        rating = self.logistic(logits)
        return rating

