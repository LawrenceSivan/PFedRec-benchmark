import torch.nn as nn

class BasePrediction(nn.Module):
    def __init__(self):
        super(BasePrediction, self).__init__()

    def forward(self, x):
        raise NotImplementedError

class MLPPrediction(BasePrediction):
    def __init__(self, input_dim):
        super(MLPPrediction, self).__init__()
        self.affine_output = nn.Linear(in_features=input_dim, out_features=1)
        self.logistic = nn.Sigmoid()

    def forward(self, x):
        logits = self.affine_output(x)
        rating = self.logistic(logits)
        return rating

