from servers.base_server import Base_Server
import torch
import logging

class PFedRec_Server(Base_Server):
    def __init__(self, config):
        super().__init__(config)
        self.config = config

    def aggregate(self, client_params_list):
        # Determine which keys to aggregate (Item Embeddings only)
        # We look for keys belonging to the embedding module
        agg_keys = [k for k in client_params_list[0].keys() if k.startswith('embedding')]

        # Initialize agg_params with the structure of the first client's update
        agg_params = {k: client_params_list[0][k].clone() for k in agg_keys}

        # Calculate average
        for key in agg_keys:
            # Stack all clients' weights for this key
            client_weights = [client[key].data.float() for client in client_params_list]
            stacked_params = torch.stack(client_weights)
            agg_params[key].data.copy_(torch.mean(stacked_params, dim=0))

        return agg_params

