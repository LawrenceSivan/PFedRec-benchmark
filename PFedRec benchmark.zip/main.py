import logging
import datetime
import os
import pandas as pd
import numpy as np
import random
import torch

from data.dataloader import SampleGenerator
from model.pfedrec_model import PFedRecModel
from model.embedding.pfedrec_embedding import PFedRecEmbedding
from clients.pfedrec_client import PFedRec_Client
from servers.pfedrec_server import PFedRec_Server
from utils.parser import parse_args
from utils.utils_checkpoint import save_checkpoint
from metrics import MetronAtK

def setup_logging(config):
    log_dir = 'logs/'
    os.makedirs(log_dir, exist_ok=True)
    current_time = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    log_file = os.path.join(log_dir, f"{config['algorithm']}_{config['dataset']}_{current_time}.log")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )

def load_data(config):
    dataset = config['dataset']
    data_dir = os.path.join("data", dataset, "ratings.dat")

    if dataset == 'ml-1m':
        rating = pd.read_csv(data_dir, sep='::', header=None,
                             names=['userId', 'itemId', 'rating', 'timestamp'],
                             engine='python')
        config['num_users'] = 6040
        config['num_items'] = 3706
    elif dataset == 'ml-100k':
        rating = pd.read_csv(data_dir, sep=',', header=None,
                             names=['userId', 'itemId', 'rating', 'timestamp'],
                             engine='python')
        config['num_users'] = 943
        config['num_items'] = 1682
    elif dataset == 'lastfm-2k':
        rating = pd.read_csv(data_dir, sep=',', header=None,
                             names=['userId', 'itemId', 'rating', 'timestamp'],
                             engine='python')
        config['num_users'] = 1892
        config['num_items'] = 17632
    elif dataset == 'amazon':
        rating = pd.read_csv(data_dir, sep=',', header=None,
                             names=['userId', 'itemId', 'rating', 'timestamp'],
                             engine='python')
    else:
         raise ValueError(f"Unknown dataset: {dataset}")

    # Reindex
    user_id = rating[['userId']].drop_duplicates().reindex()
    user_id['new_userId'] = np.arange(len(user_id))
    rating = pd.merge(rating, user_id, on=['userId'], how='left')

    item_id = rating[['itemId']].drop_duplicates()
    item_id['new_itemId'] = np.arange(len(item_id))
    rating = pd.merge(rating, item_id, on=['itemId'], how='left')

    rating = rating[['new_userId', 'new_itemId', 'rating', 'timestamp']]
    rating.columns = ['userId', 'itemId', 'rating', 'timestamp']

    config['num_users'] = rating['userId'].nunique()
    config['num_items'] = rating['itemId'].nunique()

    return SampleGenerator(rating)

def evaluate(config, server, clients, test_data, metron, global_item_embeddings, model_template):
    test_users_t = test_data[0]
    test_items_t = test_data[1]
    neg_users_t = test_data[2]
    neg_items_t = test_data[3]

    if config['use_cuda']:
        test_users_t = test_users_t.cuda()
        test_items_t = test_items_t.cuda()
        neg_users_t = neg_users_t.cuda()
        neg_items_t = neg_items_t.cuda()

    unique_test_users = torch.unique(test_users_t)

    batch_test_users = []
    batch_test_items = []
    batch_test_scores = []

    batch_neg_users = []
    batch_neg_items = []
    batch_neg_scores = []

    temp_model = model_template

    if global_item_embeddings:
        temp_model.embedding.load_state_dict(global_item_embeddings, strict=False)

    for u in unique_test_users:

        u_id = u.item()

        # Test Item
        idx_test = (test_users_t == u)
        u_test_items = test_items_t[idx_test]

        # Neg Items
        idx_neg = (neg_users_t == u)
        u_neg_items = neg_items_t[idx_neg]

        if u_id in clients:
            client = clients[u_id]
            u_test_preds = client.evaluate(u_test_items, global_item_embeddings)
            u_neg_preds = client.evaluate(u_neg_items, global_item_embeddings)
        else:
            temp_model.eval()
            with torch.no_grad():
                 u_test_preds = temp_model(u_test_items)
                 u_neg_preds = temp_model(u_neg_items)

            u_test_preds = u_test_preds.cpu()
            u_neg_preds = u_neg_preds.cpu()

        batch_test_users.extend([u_id] * len(u_test_items))
        batch_test_items.extend(u_test_items.tolist())
        batch_test_scores.extend(u_test_preds.view(-1).tolist())

        batch_neg_users.extend([u_id] * len(u_neg_items))
        batch_neg_items.extend(u_neg_items.tolist())
        batch_neg_scores.extend(u_neg_preds.view(-1).tolist())

    metron.subjects = [batch_test_users, batch_test_items, batch_test_scores,
                       batch_neg_users, batch_neg_items, batch_neg_scores]

    hr = metron.cal_hit_ratio()
    ndcg = metron.cal_ndcg()

    return hr, ndcg

if __name__ == '__main__':
    args = parse_args()
    config = vars(args)
    setup_logging(config)

    logging.info(f"Configuration: {config}")

    sample_generator = load_data(config)
    test_data = sample_generator.test_data
    validate_data = sample_generator.validate_data

    model_template = PFedRecModel(config)
    logging.info(f"Model: {model_template}")

    server = PFedRec_Server(config)

    clients = {}  # userId -> Client object

    temp_embedding = PFedRecEmbedding(config['num_items'], config['latent_dim'])
    global_item_embeddings = temp_embedding.state_dict()

    metron = MetronAtK(top_k=10)

    best_hr = 0.0
    best_ndcg = 0.0

    best_val_hr = 0.0

    for round_id in range(config['num_round']):
        logging.info('-' * 80)
        logging.info(f'Round {round_id} starts !')

        # 1. Sample Participants
        if config['clients_sample_ratio'] <= 1:
            num_participants = int(config['num_users'] * config['clients_sample_ratio'])
            participants = random.sample(range(config['num_users']), num_participants)
        else:
            participants = random.sample(range(config['num_users']), config['clients_sample_num'])

        logging.info(f"Round {round_id}: {len(participants)} participants.")

        # 2. Get Training Data for this round
        all_train_data = sample_generator.store_all_train_data(config['num_negative'])

        user_data_map = {}
        for idx, u_list in enumerate(all_train_data[0]):
            if len(u_list) > 0:
                uid = u_list[0]
                user_data_map[uid] = idx

        participant_params_list = []
        loss_list = []

        for user_id in participants:
            if user_id not in user_data_map:
                continue

            if user_id not in clients:
                clients[user_id] = PFedRec_Client(user_id, config, model_template)

            client = clients[user_id]

            data_idx = user_data_map[user_id]
            user_data = [all_train_data[0][data_idx], all_train_data[1][data_idx], all_train_data[2][data_idx]]

            client_item_params, loss = client.train(user_data, global_item_embeddings)

            participant_params_list.append(client_item_params)
            loss_list.append(loss)

        avg_loss = sum(loss_list) / len(loss_list)
        logging.info(f"Round {round_id} Average Loss: {avg_loss:.4f}")

        # 3. Aggregate
        if participant_params_list:
            global_item_embeddings = server.aggregate(participant_params_list)

        # 4. Evaluation

        logging.info("Testing phase...")
        hr, ndcg = evaluate(config, server, clients, test_data, metron, global_item_embeddings, model_template)
        logging.info(f"[Testing Round {round_id}] HR@10: {hr:.4f}, NDCG@10: {ndcg:.4f}")

        logging.info("Validating phase...")
        val_hr, val_ndcg = evaluate(config, server, clients, validate_data, metron, global_item_embeddings, model_template)
        logging.info(f"[Validating Round {round_id}] HR@10: {val_hr:.4f}, NDCG@10: {val_ndcg:.4f}")

        # Checkpoint based on Validation HR
        if val_hr > best_val_hr:
            best_val_hr = val_hr
            # best_ndcg = ndcg # Track if needed
            logging.info(f"New best Validation HR: {best_val_hr:.4f}! Saving checkpoint.")
            save_checkpoint(global_item_embeddings,
                            os.path.join('checkpoints', f"{config['algorithm']}_{config['dataset']}_best.pth"))









